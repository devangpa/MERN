module.exports = () => {
    return `<div> This will contain the link w/ token required to reset password </div>`;
};