// Rename this file to dev.js
module.exports = {
    mongoURI: 'DB connection here',
    SESSION_SECRET: 'session key phrase here'
};