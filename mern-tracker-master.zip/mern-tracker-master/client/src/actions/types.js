export const AUTH_USER = 'auth_user';
export const FETCH_TASKS = 'fetch_tasks';
export const DELETE_TASK = 'delete_task';
export const FETCH_DETAILS = 'fetch_details';
export const AUTH_ERROR = 'auth_error';
export const AUTH_CLEAR = 'auth_clear';