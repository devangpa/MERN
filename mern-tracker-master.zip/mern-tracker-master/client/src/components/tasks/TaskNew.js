import React, { Component } from 'react';
import TaskForm from './TaskForm';

class TaskNew extends Component {
    render() {
        return (
            <TaskForm />
        );
    }
}

export default TaskNew;