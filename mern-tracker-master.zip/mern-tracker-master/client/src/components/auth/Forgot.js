import React, { Component } from 'react';

class Forgot extends Component {
    render() {
        return (
            <div className="container">
                
            </div>
        );
    }
}

export default Forgot;